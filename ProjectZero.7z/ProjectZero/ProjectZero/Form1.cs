﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectZero
{
    public partial class Form1 : Form
    {
        private List<string> preElementNode = new List<string>();

        public Form1()
        {
            InitializeComponent();
        }

        private void find_Click(object sender, EventArgs e)
        {
            AddToPreElementNode();
            Algorithms algor = new Algorithms();
            algor.CreateListOfElementNode(preElementNode);

            foreach (var v in algor.FinalList)
            {
                MessageBox.Show(v.NodeName + ", level " + v.Level);
            }

        }

        private void oxygen_TextChanged(object sender, EventArgs e)
        {
            NumberCheck(oxygen.Text);
        }

        private void hydrogen_TextChanged(object sender, EventArgs e)
        {
            NumberCheck(hydrogen.Text);
        }

        private void carbon_TextChanged(object sender, EventArgs e)
        {
            NumberCheck(carbon.Text);
        }

        private void NumberCheck(string value)
        {
            bool check;
            int n;

            if (check = !Int32.TryParse(value, out n) && value != null)
            {
                SendKeys.Send("{BACKSPACE}");
            }
        }

        private void AddToPreElementNode()
        {
            try
            {
                if (Convert.ToInt32(carbon.Text) >= 1)
                {
                    for (int i = Convert.ToInt32(carbon.Text) - 1; i >= 0; i--)
                    {
                        preElementNode.Add("Carbon");
                    }
                }
                if (Convert.ToInt32(oxygen.Text) >= 1)
                {
                    for (int i = Convert.ToInt32(oxygen.Text) - 1; i >= 0; i--)
                    {
                        preElementNode.Add("Oxygen");
                    }
                }
                if (Convert.ToInt32(hydrogen.Text) >= 1)
                {
                    for (int i = Convert.ToInt32(hydrogen.Text) - 1; i >= 0; i--)
                    {
                        preElementNode.Add("Hydrogen");
                    }
                }
            }
            catch (FormatException)
            {

            }
        }
    }
}
