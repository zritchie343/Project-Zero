﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ProjectZero
{

    public class Elements
    {
        public Elements()
        {

        }

        public int AtomicNumber { get; set; }
        public string Element { get; set; }
        public string Symbol { get; set; }
        public decimal AtomicWeight { get; set; }
        public int Period { get; set; }
        public int Group { get; set; }
        public string Phase { get; set; }
        public string MostStableCrystal { get; set; }
        public string TypeOf { get; set; }
        public decimal IonicRadius { get; set; }
        public decimal AtomicRadius { get; set; }
        public decimal Electronegativity { get; set; }
        public decimal FirstIonizationPotential { get; set; }
        public decimal Density { get; set; }
        public decimal MeltingPoint { get; set; }
        public decimal BoilingPoint { get; set; }
        public int Isotopes { get; set; }
        public string Discoverer { get; set; }
        public int YearofDiscovery { get; set; }
        public decimal SpecificHeatCapacity { get; set; }
        public string ElectronConfiguration { get; set; }
        public int DisplayRow { get; set; }
        public int DisplayColumn { get; set; }

    }
}
