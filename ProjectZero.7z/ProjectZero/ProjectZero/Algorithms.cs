﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace ProjectZero
{
    public class Algorithms : Form1
    {
        public LinkedList<Elements> ListOfElements = new LinkedList<Elements>();
        public List<ElementNode> ListOfElementNodes = new List<ElementNode>();
        //public LinkedList<ElementNode> ListOfElementNodesReadyToBeAdded = new LinkedList<ElementNode>();
        public ITree<ElementNode> Tree = NodeTree<ElementNode>.NewTree();
        public int nodeLevel = 0;
        public LinkedList<ElementNode> FinalList = new LinkedList<ElementNode>();


        // Reads in comma delimited file and turns it into element object
        public void ReadElementFile(LinkedList<Elements> listOfElements)
        {
            string line;

            //Creating List in which all the element objects will be held
            //LinkedList<Elements> listOfElements = new LinkedList<Elements>();

            //Creating list to store element properties as their convert to correct types
            List<string> listPlaceHolder = new List<string>();

            //Reading in elements of periodic table one at a time
            StreamReader readFile = new StreamReader("Table of Elements.csv");
            readFile.ReadLine();

            //Create each element change each value to the correct type and add 
            while ((line = readFile.ReadLine()) != null)
            {
                foreach (var piece in line.Split(','))
                {
                    listPlaceHolder.Add(piece);
                }

                // ADD
                // Name element object after its actual name
                //string elementName = placeHolder[1];


                Elements ele = new Elements();

                try
                {
                    //Atomic Number
                    ele.AtomicNumber = Convert.ToInt32(listPlaceHolder[0]);
                    //Element
                    ele.Element = listPlaceHolder[1];
                    //Symbol
                    ele.Symbol = listPlaceHolder[2];
                    //Atomic Weight
                    ele.AtomicWeight = Convert.ToDecimal(listPlaceHolder[3]);
                    //Period               
                    ele.Period = Convert.ToInt32(listPlaceHolder[4]);
                    //Group
                    ele.Group = Convert.ToInt32(listPlaceHolder[5]);
                    //Phase
                    ele.Phase = listPlaceHolder[6];
                    //Most Stable Crystal
                    ele.MostStableCrystal = listPlaceHolder[7];
                    //TypeOf
                    ele.TypeOf = listPlaceHolder[8];
                    //Ionic Radius
                    ele.IonicRadius = Convert.ToDecimal(listPlaceHolder[9]);
                    //Atomic Radius
                    ele.AtomicRadius = Convert.ToDecimal(listPlaceHolder[10]);
                    //Electronegativity
                    ele.Electronegativity = Convert.ToDecimal(listPlaceHolder[11]);
                    //First Ionization Potential
                    ele.FirstIonizationPotential = Convert.ToDecimal(listPlaceHolder[12]);
                    //Density
                    ele.Density = Convert.ToDecimal(listPlaceHolder[13]);
                    //Melting Point
                    ele.MeltingPoint = Convert.ToDecimal(listPlaceHolder[14]);
                    //Boiling Point
                    ele.BoilingPoint = Convert.ToDecimal(listPlaceHolder[15]);
                    //Isotopes
                    ele.Isotopes = Convert.ToInt32(listPlaceHolder[16]);
                    //Discoverer
                    ele.Discoverer = listPlaceHolder[17];
                    //Year of Discovery
                    ele.YearofDiscovery = Convert.ToInt32(listPlaceHolder[18]);
                    //Specific Heat Capacity
                    ele.SpecificHeatCapacity = Convert.ToDecimal(listPlaceHolder[19]);
                    //Electron Configuration
                    ele.ElectronConfiguration = listPlaceHolder[20];
                    //Display Row
                    ele.DisplayRow = Convert.ToInt32(listPlaceHolder[21]);
                    //Display Column
                    ele.DisplayColumn = Convert.ToInt32(listPlaceHolder[22]);
                }
                catch (FormatException)
                {

                }


                listOfElements.AddLast(ele);

                //Clear out place holder so it can be used 
                //for the next iteration of the loop
                listPlaceHolder.Clear();
            }
            readFile.Close();
        }

        public void CreateListOfElementNode(List<string> formdata)
        {
            ReadElementFile(ListOfElements);

            //This will create a list of elementnodes that have required info for p0
            foreach (var userdata in formdata)
            {
                foreach (var element in ListOfElements)
                {
                    if (userdata == element.Element)
                    {
                        ElementNode node = new ElementNode();

                        node.NameOfElement = userdata;

                        int atomicnumber = element.AtomicNumber;

                        //The "if" statements below calculate the available electrons in the valence shells

                        // I Energy level - 2
                        if (atomicnumber <= 2)
                        {
                            node.AvailableElectrons = atomicnumber;
                        }
                        // II Energy level - 8
                        if ((atomicnumber <= 10) && (atomicnumber > 2))
                        {
                            atomicnumber = 10 - atomicnumber;
                            node.AvailableElectrons = atomicnumber;
                        }
                        // III Energy level - 18
                        if ((atomicnumber <= 28) && (atomicnumber > 10))
                        {
                            atomicnumber = 28 - atomicnumber;
                            node.AvailableElectrons = atomicnumber;
                        }
                        // IV Energy level - 32
                        if ((atomicnumber <= 60) && (atomicnumber > 28))
                        {
                            atomicnumber = 60 - atomicnumber;
                            node.AvailableElectrons = atomicnumber;
                        }
                        // V Energy level - 50
                        if ((atomicnumber <= 110) && (atomicnumber > 60))
                        {
                            atomicnumber = 110 - atomicnumber;
                            node.AvailableElectrons = atomicnumber;
                        }
                        // VI  Energy level - 72
                        if ((atomicnumber <= 182) && (atomicnumber > 110))
                        {
                            atomicnumber = 182 - atomicnumber;
                            node.AvailableElectrons = atomicnumber;
                        }



                        int repeatingNum = 1;

                        //The algorithm below adds a number to each elementnode and increments for ones that repeat
                        // Generate number for repeating nodes
                        foreach (var completeNode in ListOfElementNodes)
                        {
                            if ((completeNode.NameOfElement == node.NameOfElement) && (repeatingNum <= completeNode.RepeatNumber))
                            {
                                repeatingNum = completeNode.RepeatNumber + 1;
                            }
                        }
                        node.RepeatNumber = repeatingNum;

                        ListOfElementNodes.Add(node);
                    }
                }
            }

            foreach (var nameOfNode in ListOfElementNodes)
            {
                nameOfNode.NodeName = nameOfNode.NameOfElement + nameOfNode.RepeatNumber.ToString();
            }

            //Each node will now carry a place holder of the current list
            //This is so that we can keep track of electrons when we are making the tree 
            foreach (var v in ListOfElementNodes)
            {
                v.PlaceHolderListELementNodes = ListOfElementNodes;
            }

            //for now lets call it in here
            NewTree();
        }

        public void NewTree()
        {
            //Create blank placeholder node so we can update LONRTBA
            ElementNode placeHolderNode = new ElementNode();

            INode<ElementNode> top = Tree.AddChild(placeHolderNode);
            top.Data.PlaceHolderListELementNodes = ListOfElementNodes;

            //placeHolderNode.PlaceHolderListELementNodes = ListOfElementNodes;
            //Add top node in the tree (does NOT matter what the first element is from that list)
            //placeHolderNode = ListOfElementNodes.First.Value.NodesReadyToBeAdded.First();

            //Subtract on Electron from first element and update NRTBA list
            ElectronCheckAdd(top);
            AvailableNodeList(top);

            Branches(top);
            nodeLevel = 0;
        }

        public INode<ElementNode> Branches(INode<ElementNode> parent)
        {
            ITree<ElementNode> treeHolder = NodeTree<ElementNode>.NewTree();
            nodeLevel++;
            //Run check to see if the node should have leaf nodes
            if (NumberOfElectronsLeft(parent.Data))
            {
                //foreach (var v in parent.Data.NodesReadyToBeAdded)
                for (int i = 0; i <= parent.Data.NodesReadyToBeAdded.Count - 1; ++i)
                {
                    //I need a place holder of the leaf before I add it to the real tree
                    INode<ElementNode> leafHolder = treeHolder.AddChild(parent.Data.NodesReadyToBeAdded[i]);


                    INode<ElementNode> leaf1 = parent.AddChild(parent.Data.NodesReadyToBeAdded[i]);
                    //INode<ElementNode> leaf = parent.Data.NodesReadyToBeAdded[i];

                    if (NodeChecker(leaf1))
                    {
                        AvailableNodeList(leaf1);

                        parent.Data.NodesReadyToBeAdded = leaf1.Data.NodesReadyToBeAdded;

                        if (NodeChecker(leaf1))
                        {
                            if (parent.HasChild == false)
                            {
                                parent.Data.AvailableElectrons = parent.Data.AvailableElectrons - 1;
                            }
                            //Adds leaf to parents child list so we can compare siblings
                            parent.Data.ChildNodes.Add(leaf1.Data);

                            //Removes Electrons from leaf since its being added
                            ElectronCheckAdd(leaf1);

                            //Tells that the node has been connect so that we can appropriatly calculate elctron count
                            leaf1.Data.HasBeenConnected = true;

                            //Records nodes level for testing purposes 
                            leaf1.Data.Level = nodeLevel;

                            //This will eventually contain the final tree or the correct itteration the molecule
                            FinalList.AddFirst(leaf1.Data);

                            //Checks for children
                            Branches(leaf1);
                            i = -1;
                            nodeLevel--;
                        }
                    }
                }
            }
            return parent;
        }

        /*Algorithm to determine what element can be used as nodes so that there are no duplicates
        updates the LONRTBA for the node
        Reference NewTree*/
        public INode<ElementNode> AvailableNodeList(INode<ElementNode> node)
        {
            bool elementTypeExistsInNRTBA = false;
            bool elementElectronCountExistsInNRTBA = false;

            //Each node will also carry a list of the available nodes 
            //  aloud to be added in the next iteration of nodes added

            //foreach (var v2 in node.Data.PlaceHolderListELementNodes)
            for (int i = 0; i <= node.Data.PlaceHolderListELementNodes.Count - 1; ++i)
            {
                if (node.Data.NodesReadyToBeAdded.Count > 0)
                {
                    for (int k = 0; k <= node.Data.NodesReadyToBeAdded.Count - 1; ++k)
                    {
                        if (node.Data.PlaceHolderListELementNodes[i].NameOfElement == node.Data.NodesReadyToBeAdded[k].NameOfElement)
                        {
                            elementTypeExistsInNRTBA = true;
                            break;
                        }
                    }

                    for (int L = 0; L <= node.Data.NodesReadyToBeAdded.Count - 1; ++L)
                    {
                        if (node.Data.PlaceHolderListELementNodes[i].AvailableElectrons == node.Data.NodesReadyToBeAdded[L].AvailableElectrons)
                        {
                            elementElectronCountExistsInNRTBA = true;
                            break;
                        }
                    }
                }

                //Wont allow hydrogens, and auto adds first node if none are in list
                if ((node.Data.PlaceHolderListELementNodes[i].AvailableElectrons > 1) && (node.Data.NodesReadyToBeAdded.Count == 0))
                {
                    node.Data.NodesReadyToBeAdded.Add(node.Data.PlaceHolderListELementNodes[i]);
                    node.Data.PlaceHolderListELementNodes.Remove(node.Data.PlaceHolderListELementNodes[i]);
                    i = -1;
                }
                else if ((node.Data.PlaceHolderListELementNodes[i].AvailableElectrons > 1) && (node.Data.NodesReadyToBeAdded.Count > 0))
                {

                    //foreach (var v3 in node.Data.NodesReadyToBeAdded)
                    for (int j = 0; j <= node.Data.NodesReadyToBeAdded.Count - 1; ++j)
                    {
                        //This checks for duplicate elements with the same node name
                        if ((node.Data.PlaceHolderListELementNodes[i].AvailableElectrons != node.Data.NodesReadyToBeAdded[j].AvailableElectrons)
                            && (node.Data.PlaceHolderListELementNodes[i].NodeName != node.Data.NodesReadyToBeAdded[j].NodeName)
                            && (node.Data.PlaceHolderListELementNodes[i].NameOfElement == node.Data.NodesReadyToBeAdded[j].NameOfElement)
                            && elementElectronCountExistsInNRTBA == false)
                        {
                            node.Data.NodesReadyToBeAdded.Add(node.Data.PlaceHolderListELementNodes[i]);
                            node.Data.PlaceHolderListELementNodes.Remove(node.Data.PlaceHolderListELementNodes[i]);
                            i = -1;
                            break;
                        }
                        //This adds new element tpyes NRTBA
                        else if (elementTypeExistsInNRTBA == false)
                        {
                            node.Data.NodesReadyToBeAdded.Add(node.Data.PlaceHolderListELementNodes[i]);
                            node.Data.PlaceHolderListELementNodes.Remove(node.Data.PlaceHolderListELementNodes[i]);
                            i = -1;
                            break;
                        }
                    }

                    elementTypeExistsInNRTBA = false;
                }
            }


            //Updates v2's lists so that if state works
            foreach (var v4 in node.Data.PlaceHolderListELementNodes)
            {
                v4.NodesReadyToBeAdded = node.Data.NodesReadyToBeAdded;
            }


            //Updates list as we get more information
            foreach (var v in node.Data.NodesReadyToBeAdded)
            {
                v.NodesReadyToBeAdded = node.Data.NodesReadyToBeAdded;
            }

            return node;
        }

        //Checks the Node to see if it is aloud to be added
        //Reference Branches
        public bool NodeChecker(INode<ElementNode> node)
        {
            bool availableElectrons = false;

            //Checks to see if the parent node has elements with more than one available electron
            foreach (var number in node.Parent.Data.PlaceHolderListELementNodes)
            {
                if (number.AvailableElectrons > 1)
                {
                    availableElectrons = true;
                    break;
                }
            }

            //Check to see if added node has electrons available
            if (node.Data.AvailableElectrons <= 0)
            {
                return false;
            }
            //Checks to see if added node is NOT the same as parent or grandparent nodes
            if ((node.Parent.Data != null) && (node.Parent.Data.NodeName == node.Data.NodeName))
            {
                return false;
            }
            if ((node.Parent.Parent.Data != null) && (node.Parent.Parent.Data.NodeName == node.Data.NodeName))
            {
                return false;
            }

            //This check is used to eliminate nodes that go nowhere when other nodes are available that go somewhere
            if ((node.Parent.Data.AvailableElectrons <= 1) && (node.Data.AvailableElectrons == 0) && (availableElectrons == true))
            {
                return false;
            }
            //Cannot be a sibling of itself
            if (node.Parent.Data.ChildNodes.Contains(node.Data))
            {
                return false;
            }

            return true;
        }

        //Run check to see if the node should have leaf nodes
        //Reference Branches
        public bool NumberOfElectronsLeft(ElementNode e)
        {
            bool AllElementInUse = true;
            bool ContinueTree = true;
            int totalelectrons = 0;

            //Checks to see how many avaialble electrons there are in LOENRTBA
            foreach (var v1 in e.NodesReadyToBeAdded)
            {
                if (v1.HasBeenConnected == true)
                {
                    totalelectrons = totalelectrons + v1.AvailableElectrons + 1;
                }
                else
                {
                    totalelectrons = totalelectrons + v1.AvailableElectrons;
                }
            }

            //Checks to see if every element is in use
            //Exception being hydrogen
            foreach (var v2 in e.PlaceHolderListELementNodes)
            {
                if (v2.NameOfElement != "Hydrogen")
                {
                    foreach (var v3 in e.NodesReadyToBeAdded)
                    {
                        if (v2.NodeName == v3.NodeName)
                        {
                            AllElementInUse = true;
                            break;
                        }
                        else
                        {
                            AllElementInUse = false;
                        }
                    }
                }

                if (AllElementInUse == false)
                {
                    break;
                }
            }

            //Checks all conditions to see if the tree should continue
            if ((totalelectrons == 0) || (totalelectrons == HydrogenElementChecker()) || (AllElementInUse == true))
            {
                ContinueTree = false;
            }

            return ContinueTree;
        }

        /*Returns the number of hydrogen elements 
        Which is directly proportional to number of electrons all the hydrogens have
        Reference NumberOfElectronsLeft*/
        public int HydrogenElementChecker()
        {
            int e = 0;

            foreach (var v in ListOfElementNodes)
            {
                if (v.NameOfElement == "Hydrogen")
                {
                    e++;
                }
            }
            return e;
        }

        //Removes electron when a node is added
        public INode<ElementNode> ElectronCheckAdd(INode<ElementNode> node)
        {

            node.Data.AvailableElectrons = node.Data.AvailableElectrons - 1;
            return node;
        }

        //Adds electrons back when a node is removed
        public INode<ElementNode> ElectronCheckRemove(INode<ElementNode> node)
        {
            //Add one for connecting to parent and one for connecting to child
            node.Data.AvailableElectrons = node.Data.AvailableElectrons + 1;

            return node;
        }
    }
}

