﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectZero
{
    public class ElementNode
    {     
        //public string NodeName { get; set; }
        //public string NameOfElement { get; set; }
        //public int AvailableElectrons { get; set; }
        //public int RepeatNumber { get; set; }
        //public LinkedList<ElementNode> PlaceHolderListELementNodes { get; set; }
        //public LinkedList<ElementNode> NodesReadyToBeAdded { get; set; }

        private string nodeName;
        private string nameOfElement;
        private int availableElectrons;
        private int level;
        private int repeatNumber;
        private bool hasBeenConnected;
        private List<ElementNode> placeHolderListELementNodes;
        private List<ElementNode> nodesReadyToBeAdded;
        private List<ElementNode> childNodes;

        public ElementNode()
        {
            PlaceHolderListELementNodes = new List<ElementNode>();
            NodesReadyToBeAdded = new List<ElementNode>();
            ChildNodes = new List<ElementNode>();
        }

        public string NodeName
        {
            get { return nodeName; }
            set { nodeName = value; }
        }
        public string NameOfElement
        {
            get { return nameOfElement; }
            set { nameOfElement = value; }
        }
        public int AvailableElectrons
        {
            get { return availableElectrons; }
            set { availableElectrons = value; }
        }
        public int Level
        {
            get { return level; }
            set { level = value; }
        }
        public bool HasBeenConnected
        {
            get { return hasBeenConnected; }
            set { hasBeenConnected = value; }
        }
        public int RepeatNumber
        {
            get { return repeatNumber; }
            set { repeatNumber = value; }
        }
        public List<ElementNode> PlaceHolderListELementNodes
        {
            get { return placeHolderListELementNodes; }
            set { placeHolderListELementNodes = value; }
        }
        public List<ElementNode> NodesReadyToBeAdded
        {
            get { return nodesReadyToBeAdded; }
            set { nodesReadyToBeAdded = value; }
        }
        public List<ElementNode> ChildNodes
        {
            get { return childNodes; }
            set { childNodes = value; }
        }

    }
}
