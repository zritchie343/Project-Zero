﻿namespace ProjectZero
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.carbon = new System.Windows.Forms.TextBox();
            this.oxygen = new System.Windows.Forms.TextBox();
            this.hydrogen = new System.Windows.Forms.TextBox();
            this.find = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(48, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Carbon";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(48, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Oxygen";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(51, 145);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Hydrogen";
            // 
            // carbon
            // 
            this.carbon.Location = new System.Drawing.Point(119, 52);
            this.carbon.Name = "carbon";
            this.carbon.Size = new System.Drawing.Size(100, 20);
            this.carbon.TabIndex = 3;
            this.carbon.TextChanged += new System.EventHandler(this.carbon_TextChanged);
            // 
            // oxygen
            // 
            this.oxygen.Location = new System.Drawing.Point(119, 98);
            this.oxygen.Name = "oxygen";
            this.oxygen.Size = new System.Drawing.Size(100, 20);
            this.oxygen.TabIndex = 4;
            this.oxygen.TextChanged += new System.EventHandler(this.oxygen_TextChanged);
            // 
            // hydrogen
            // 
            this.hydrogen.Location = new System.Drawing.Point(119, 137);
            this.hydrogen.Name = "hydrogen";
            this.hydrogen.Size = new System.Drawing.Size(100, 20);
            this.hydrogen.TabIndex = 5;
            this.hydrogen.TextChanged += new System.EventHandler(this.hydrogen_TextChanged);
            // 
            // find
            // 
            this.find.Location = new System.Drawing.Point(130, 192);
            this.find.Name = "find";
            this.find.Size = new System.Drawing.Size(75, 23);
            this.find.TabIndex = 6;
            this.find.Text = "Find";
            this.find.UseVisualStyleBackColor = true;
            this.find.Click += new System.EventHandler(this.find_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(349, 324);
            this.Controls.Add(this.find);
            this.Controls.Add(this.hydrogen);
            this.Controls.Add(this.oxygen);
            this.Controls.Add(this.carbon);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox carbon;
        private System.Windows.Forms.TextBox oxygen;
        private System.Windows.Forms.TextBox hydrogen;
        private System.Windows.Forms.Button find;
    }
}

